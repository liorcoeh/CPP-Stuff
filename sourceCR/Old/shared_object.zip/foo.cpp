

#include <iostream>

#include "foo.hpp"

void foo()
{
    std::cout << "Hello, I am a shared library" << std::endl;
}