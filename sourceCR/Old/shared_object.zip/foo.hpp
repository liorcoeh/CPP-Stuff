

#ifndef FOO_HPP
#define FOO_HPP

#include <iostream>

void foo();

#endif // FOO_HPP